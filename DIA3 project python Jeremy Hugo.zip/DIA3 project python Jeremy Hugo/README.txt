Hello Sir, 

You have 2 notebooks, 

1 for data visualization, and the other for machine learning. 

If you want to load the API model, you have to start the app.py, take the URL on local host and use this. 

After, you will have to complete the cells with correct values (which are written on the left), go to predict and you will have your prediction 




Best Regards, 

Hugo COQUEBLIN & Jérémy CONSTANTIN


NOTE TO READ : Our model flask was way to big ! (1.4Go) because we didn't limited the number of leaf etc. 
So to correct this, we had to sample our data by 2500 over 40 000 to have a model flask at around 20Mo so it can be uploaded on Github !


Conclusion : 

Random Forest : Accuracy of around 0.59235 
Neural Network : Accuracy of around 0.58452 
Gradient Boosting Classifier : 0.594031

Remark : we could drastically improve our accuary by only classify by no readmitted and readmitted, but we keep the >30 days and <30 days so it’s a 3 classes classification.


In relation to our subject of study, a forecast seems difficult to make. With an accuracy of 0.61 - 0.62, the results are promising but not good enough to be applicable in medical settings. 

To improve our accuracy, we would have needed a database with more information, or evenly distributed classes (we have a lot of non-readmitted compared to other classes)
